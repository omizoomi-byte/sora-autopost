"""
generate_token_secret.py
========================
Run this ONCE on your laptop after doing --setup.
It prints the base64-encoded token you need to paste into GitHub Secrets.

Usage:
    python generate_token_secret.py
"""

import base64
import sys
from pathlib import Path

TOKEN_FILE = "data/token.pickle"

def main():
    path = Path(TOKEN_FILE)
    if not path.exists():
        print(f"\n❌ Token not found at '{TOKEN_FILE}'")
        print("Run this first:  python youtube_poster.py --setup\n")
        sys.exit(1)

    with open(path, "rb") as f:
        raw = f.read()

    encoded = base64.b64encode(raw).decode("utf-8")

    print("\n" + "="*60)
    print("  YOUTUBE_TOKEN secret value")
    print("="*60)
    print(encoded)
    print("="*60)
    print()
    print("Next steps:")
    print("  1. Copy ALL the text between the === lines above")
    print("  2. Go to your GitHub repo → Settings → Secrets and variables → Actions")
    print("  3. Click 'New repository secret'")
    print("  4. Name:  YOUTUBE_TOKEN")
    print("  5. Value: paste the text you copied")
    print("  6. Click 'Add secret'")
    print()
    print("That's it! GitHub Actions will use this token to post to YouTube.")
    print("The token auto-refreshes, so you only need to do this once.\n")

if __name__ == "__main__":
    main()
