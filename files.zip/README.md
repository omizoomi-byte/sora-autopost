# YouTube Shorts Auto-Poster 🎬
Posts one Sora prompt per day to your YouTube channel — even when your laptop is off.
Powered by **GitHub Actions** (free, runs in the cloud).

---

## How it works
GitHub Actions runs the poster script every day at 09:00 UTC on GitHub's servers.
After each post, it commits the updated `used_ideas.json` tracker back to the repo
so the next day it knows exactly where to continue.

---

## Setup (~15 minutes, one time only)

### Step 1 — Install dependencies on your laptop
```bash
pip install google-auth google-auth-oauthlib google-auth-httplib2 \
            google-api-python-client pandas openpyxl
```

### Step 2 — Get Google API credentials
1. Go to https://console.cloud.google.com
2. Create a new project
3. Enable **YouTube Data API v3**
4. Go to **APIs & Services → Credentials**
5. Create **OAuth 2.0 Client ID** → Desktop App
6. Download JSON → rename to `client_secrets.json` and place it here

### Step 3 — Authenticate on your laptop (one time)
```bash
python youtube_poster.py --setup
```
A browser opens — log in with your YouTube account and approve access.

### Step 4 — Generate your GitHub secret
```bash
python generate_token_secret.py
```
Prints a long encoded string. Copy it.

### Step 5 — Push to a private GitHub repo
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### Step 6 — Add the secret to GitHub
Repo → **Settings → Secrets and variables → Actions → New repository secret**
- Name: `YOUTUBE_TOKEN`
- Value: the string you copied in Step 4

### Step 7 — Enable Actions
Go to the **Actions** tab in your repo and enable workflows. Done! 🎉

---

## Manual trigger
Actions tab → Daily YouTube Shorts Post → **Run workflow**

---

## Changing the post time
Edit `.github/workflows/daily_post.yml`:
```yaml
- cron: '0 9 * * *'   # 09:00 UTC
```
| Your time | UTC cron |
|---|---|
| 9:00 AM UK (winter) | `0 9 * * *` |
| 9:00 AM UK (summer) | `0 8 * * *` |
| 9:00 AM New York | `0 14 * * *` |

---

## Files
```
├── youtube_poster.py              ← main script
├── generate_token_secret.py       ← run once to get your GitHub secret
├── client_secrets.json            ← YOU add (don't commit to public repo!)
├── .github/workflows/daily_post.yml  ← GitHub Actions schedule
└── data/
    ├── video_ideas.xlsx           ← your 1000 Sora prompts
    ├── used_ideas.json            ← auto-updated after each post
    └── token.pickle               ← saved login (don't commit!)
```

> ⚠️ Add `client_secrets.json` and `data/token.pickle` to `.gitignore` if making the repo public.
